"""Groupware package."""
