"""suremeetingroom-bot package."""
